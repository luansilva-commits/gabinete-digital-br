Executar schema.sql e configurar Google Auth.
