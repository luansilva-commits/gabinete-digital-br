Next.js app.
