Sprint1: Login, Dashboard, Projetos
Sprint2: Processos, Agenda, Decisões
Sprint3: PGD e IA
