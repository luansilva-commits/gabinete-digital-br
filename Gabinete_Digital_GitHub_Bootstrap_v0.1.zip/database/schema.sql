
create table organizations(id uuid primary key,name text);
create table campuses(id uuid primary key,organization_id uuid,name text);
create table profiles(id uuid primary key,campus_id uuid,full_name text,email text);
create table projects(id uuid primary key,title text,status text,priority text,next_action text,due_date date);
create table processes(id uuid primary key,project_id uuid,number text,subject text,status text);
create table meetings(id uuid primary key,project_id uuid,title text,meeting_date timestamp);
create table decisions(id uuid primary key,project_id uuid,title text,decision text,legal_basis text);
create table pgd_deliveries(id uuid primary key,project_id uuid,month text,delivery text,evidence text);
